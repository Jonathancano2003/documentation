// index.js
const express = require('express');
const cors = require('cors');
const db = require('./db'); 
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

let loggedInUser = null;

// ---------- LOGIN ----------
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  //   Query Builder para buscar el usuario en la tabla "users"
  // .where({ username, password }) genera un WHERE con esas condiciones
  // .first() obtiene solo el primer resultado encontrado
  const user = await db('users')
    .where({ username, password })
    .first();

  if (user) {
    loggedInUser = user; // Guardamos el usuario logueado
    console.log(`🔑 Usuario logeado: ${username} (${new Date().toLocaleString()})`);
    res.json({ success: true, user });
  } else {
    console.log(`❌ Intento de login fallido: ${username} (${new Date().toLocaleString()})`);
    res.status(401).json({ success: false, message: 'Credenciales inválidas' });
  }
});

// ---------- LOGOUT ----------
app.post('/api/logout', (req, res) => {
  loggedInUser = null;
  res.json({ success: true });
});

// ---------- OBTENER USUARIOS ----------
app.get('/api/users', async (req, res) => {
  if (!loggedInUser) return res.status(401).json({ message: 'No autorizado' });

  //   seleccionar todos los usuarios
 
  const users = await db('users').select('id', 'username', 'nombre');
  console.log("Usuarios devueltos");
  res.json(users);
});

// ---------- CREAR USUARIO ----------
app.post('/api/users', async (req, res) => {
  const { username, password, nombre } = req.body;

  //   insertar un nuevo usuario

  await db('users').insert({ username, password, nombre });
  res.json({ username, nombre });
});

// ---------- EDITAR USUARIO ----------
app.put('/api/users/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  const { username, nombre } = req.body;

  //   actualizar datos de un usuario
  // .where({ id }) selecciona el usuario por su id

  const updated = await db('users')
    .where({ id })
    .update({ username, nombre });

  if (!updated) return res.status(404).json({ message: 'No encontrado' });
  res.json({ success: true });
});

// ---------- ELIMINAR USUARIO ----------
app.delete('/api/users/:id', async (req, res) => {
  const id = parseInt(req.params.id);

  //   eliminar un usuario por su id
  // .del() ejecuta un DELETE
  await db('users').where({ id }).del();
  res.json({ success: true });
});

app.listen(PORT, () => {
  console.log(`✅ Backend corriendo en http://localhost:${PORT}`);
});
