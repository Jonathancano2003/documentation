<template>
  <q-page class="q-pa-md flex flex-center">
    <q-card>
      <q-card-section>
        <div class="text-h6">Iniciar Sesión</div>
        <q-input v-model="username" label="Usuario" />
        <q-input v-model="password" label="Contraseña" type="password" />
        <q-btn label="Entrar" color="primary" class="q-mt-md" @click="login" />
        <div v-if="error" class="text-negative q-mt-sm">{{ error }}</div>
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { api } from 'boot/axios'

const router = useRouter()
const username = ref('')
const password = ref('')
const error = ref('')

const login = async () => {
  try {
    const res = await api.post('/login', { username: username.value, password: password.value })
    if (res.data.success) {
      router.push('/users')
    } else {
      error.value = 'Credenciales inválidas'
    }
  } catch (err) {
    if (err.response && err.response.status === 401) {
      error.value = 'Credenciales inválidas'
    } else {
      error.value = 'Error en el servidor'
    }
  }
}

</script>
