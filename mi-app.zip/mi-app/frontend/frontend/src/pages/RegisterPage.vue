<template>
  <q-page class="q-pa-md flex flex-center">
    <q-card>
      <q-card-section>
        <div class="text-h6">Registro</div>
        <q-input v-model="username" label="Usuario" />
        <q-input v-model="password" label="Contraseña" type="password" />
        <q-input v-model="nombre" label="Nombre completo" />
        <q-btn label="Registrar" color="primary" class="q-mt-md" @click="register" />
        <div v-if="message" class="q-mt-sm">{{ message }}</div>
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script setup>
import { ref } from 'vue'
import { api } from 'boot/axios'

const username = ref('')
const password = ref('')
const nombre = ref('')
const message = ref('')

const register = async () => {
  try {
    await api.post('/users', {
      username: username.value,
      password: password.value,
      nombre: nombre.value
    })
    message.value = 'Usuario creado correctamente'
  } catch {
    message.value = 'Error al crear usuario'
  }
}
</script>
