<template>
  <q-page class="q-pa-md">
    <q-table
      :rows="users"
      :columns="columns"
      row-key="id"
    >
      <template #body-cell-actions="props">
        <q-btn
          flat icon="edit"
          color="primary"
          @click="editUser(props.row)"
        />
        <q-btn
          flat icon="delete"
          color="negative"
          @click="deleteUser(props.row.id)"
        />
      </template>
    </q-table>

    <!-- Modal para editar usuario -->
    <q-dialog v-model="editDialog">
      <q-card>
        <q-card-section>
          <div class="text-h6">Editar Usuario</div>
          <q-input v-model="editUserData.username" label="Usuario" />
          <q-input v-model="editUserData.nombre" label="Nombre" />
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="Cancelar" v-close-popup />
          <q-btn flat label="Guardar" color="primary" @click="saveEdit" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { api } from 'boot/axios'

const users = ref([])

const columns = [
  { name: 'id', label: 'ID', field: 'id' },
  { name: 'username', label: 'Usuario', field: 'username' },
  { name: 'nombre', label: 'Nombre', field: 'nombre' },
  { name: 'actions', label: 'Acciones', field: 'actions' }
]

const editDialog = ref(false)
const editUserData = ref({ id: null, username: '', nombre: '' })

async function loadUsers() {
  try {
    const res = await api.get('/users')
    users.value = res.data
  } catch (err) {
   
    if (err.response && err.response.status === 401) {
      window.location = '/login'
    } else {
      users.value = []
    }
  }
}

onMounted(loadUsers)

function editUser(user) {
  editUserData.value = { ...user }
  editDialog.value = true
}

async function saveEdit() {
  try {
    await api.put(`/users/${editUserData.value.id}`, {
      username: editUserData.value.username,
      nombre: editUserData.value.nombre
    })
    editDialog.value = false
    await loadUsers()
  } catch {
     alert('Error al guardar los cambios')
  }
}

async function deleteUser(id) {
  if (confirm('¿Seguro que quieres eliminar este usuario?')) {
    await api.delete(`/users/${id}`)
    await loadUsers()
  }
}
</script>
