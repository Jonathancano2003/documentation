<script setup>
import ChatCliente from './components/ChatCliente.vue'
</script>

<template>
  <ChatCliente />
</template>

<style scoped>
/* Aquí puedes poner estilos si quieres */
</style>
