<template>
  <div>
    <!-- Username input -->
    <input
      v-model="username"
      class="txt-username"
      type="text"
      placeholder="Username"
    />

    <!-- Chat message list -->
    <div class="div-chat">
      <p v-for="(message, idx) in listMessages" :key="idx">
        {{ message.user }}: {{ message.body }}
      </p>
    </div>

    <!-- Message input form -->
    <form @submit.prevent="handleSubmit" class="form">
      <span class="title">Chat</span>
      <p class="description">Type your message.</p>
      <div class="div-type-chat">
        <input
          v-model="message"
          placeholder="Type your message"
          type="text"
          class="input-style"
        />
        <button type="submit">Send</button>
      </div>
    </form>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'
import { io } from 'socket.io-client'

// Connect to the Socket.IO server
const socket = io('https://chat-server-edwin-dev.onrender.com/')

// Reactive references
const username = ref('Machine')
const message = ref('')
const listMessages = ref([
  { body: 'Welcome to the chat room', user: 'Machine' }
])

// Function to send a message
function handleSubmit() {
  const newMsg = { body: message.value, user: username.value }
  socket.emit('message', newMsg)
  listMessages.value.push(newMsg)
  message.value = ''
}

// Function to receive incoming messages
function receiveMessage(msg) {
  listMessages.value.push(msg)
}

// Register and clean up the socket listener
onMounted(() => {
  socket.on('message', receiveMessage)
})

onBeforeUnmount(() => {
  socket.off('message', receiveMessage)
})
</script>

<style scoped>
/* Add your own styles here if needed */
</style>
