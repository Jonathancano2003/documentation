// Import required modules
import express from "express"; // Express framework for handling HTTP requests
import morgan from "morgan";   // Middleware for logging HTTP requests
import { createServer } from "http"; // To create a raw HTTP server
import { Server as SocketServer } from "socket.io"; // Import and alias Socket.IO Server
import cors from "cors";       // Middleware to enable Cross-Origin Resource Sharing
import { PORT } from "./config.js"; // Import port number from config.js

// Initialize Express app
const app = express();

// Create the HTTP server using the Express app
const server = createServer(app);

// Initialize Socket.IO server and allow all origins (CORS)
const io = new SocketServer(server, {
  cors: {
    origin: "*", // Allow connections from any origin
  },
});

// Apply middleware to the Express app
app.use(cors());         // Allow cross-origin requests
app.use(morgan("dev"));  // Log requests in development format

// Handle WebSocket connections
io.on("connection", (socket) => {
  console.log("🟢 New client connected");

  // Listen for "message" events from the client
  socket.on("message", (msg) => {
    // Broadcast the received message to all other connected clients
    socket.broadcast.emit("message", {
      body: msg.body,
      user: msg.user,
    });
  });

  // Handle client disconnection
  socket.on("disconnect", () => {
    console.log("🔴 Client disconnected");
  });
});

// Start the HTTP server and listen on the specified port
server.listen(PORT, () => {
  console.log("✅ Server started on port " + PORT);
});
