// Import Express (make sure you ran `npm install express`)
const express = require('express');

// Initialize the Express application
const app = express();

// Define the server port
const PORT = 3000;

// Middleware to parse incoming JSON requests
app.use(express.json());
// Middleware to handle plain text requests (Content-Type: text/plain)
app.use(express.text());

// Middleware to handle raw binary data (Content-Type: application/octet-stream)
app.use(express.raw());
// Middleware to parse URL-encoded data (e.g., from HTML forms)
app.use(express.urlencoded({ extended: true }));

// Define a GET route for the root URL
app.get('/', (req, res) => {
  res.send('Basic Express server is running ✅');
});

// Define a POST route for testing data input
app.post('/pipo', (req, res) => {
  // Get the value of "nombre" from query parameters (e.g., /pipo?nombre=John)
  const valor = req.query.nombre;

  // Get the value of "nombre" from the request body (when sent as raw JSON)
  const valor2 = req.body.nombre;

  // Send a response to confirm the server is working
  res.send('Basic Express server is running ✅');
});

// Start the server and listen on the specified port
app.listen(PORT, () => {
  console.log(`Server is listening at http://localhost:${PORT}`);
});
