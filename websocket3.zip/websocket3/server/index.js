import express from 'express'
import { createServer } from 'http'
import { Server as SocketServer } from 'socket.io'
import cors from 'cors'
import { PORT } from './config.js'

const app = express()
const server = createServer(app)
const io = new SocketServer(server, {
  cors: { origin: '*' }
})

app.use(cors())

const grupo1 = [12, 45, 78]
const grupo2 = [3, 9, 27]
const grupo3 = [100, 200, 300]
let valor1, valor2, valor3

let i1 = 0, i2 = 0, i3 = 0

setInterval(() => {
  valor1 = grupo1[i1 % grupo1.length]
  valor2 = grupo2[i2 % grupo2.length]
  valor3 = grupo3[i3 % grupo3.length]

  io.emit('update1', valor1)
  io.emit('Values', [valor1, valor2, valor3])
  console.log(`update1 → ${valor1}`)

  i1++
}, 1000)

setInterval(() => {
  const valor2 = grupo2[i2 % grupo2.length]
  io.emit('update2', valor2)
  console.log(`update2 → ${valor2}`)
  i2++
}, 2000)

setInterval(() => {
  const valor3 = grupo3[i3 % grupo3.length]
  io.emit('update3', valor3)
  console.log(`update3 → ${valor3}`)
  i3++
}, 3000)

app.get('/api/mensaje', (req, res) => {
  res.json({ mensaje: 'Hola desde HTTP' })
})

io.on('connection', (socket) => {
  console.log('🟢 Cliente conectado')

  socket.on('mensaje', (texto) => {
    console.log('📩 Mensaje recibido por WebSocket:', texto)
    io.emit('respuesta', `Servidor recibió: ${texto}`)
  })

  socket.on('disconnect', () => {
    console.log('🔴 Cliente desconectado')
  })
})

server.listen(PORT, () => {
  console.log(`✅ Servidor backend escuchando en http://localhost:${PORT}`)
})
