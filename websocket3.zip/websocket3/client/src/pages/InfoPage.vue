<template>
  <div class="container">
    <h1>{{ mensaje }}</h1>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const mensaje = ref('info.vue')
</script>

<style>

</style> 
