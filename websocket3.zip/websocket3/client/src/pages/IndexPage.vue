<template>
  <q-page class="q-pa-lg">

    <h3>Valores automáticos</h3>
    <div>Variable 1: {{ var1 }}</div>
    <div>Variable 2: {{ var2 }}</div>
    <div>Variable 3: {{ var3 }}</div>
    <div>Valores combinados: {{ varVal[0] }} - {{ varVal[1] }} - {{ varVal[2] }}</div>

    <q-separator class="q-my-lg" />

    <h3>WebSocket (input)</h3>
    <q-input v-model="mensajeWS" label="Escribe mensaje WebSocket" filled />
    <q-btn label="Enviar por WebSocket" color="secondary" class="q-mt-sm" @click="enviarPorWebSocket" />

    <div class="q-mt-sm">
      <strong>Historial WebSocket:</strong>
      <ul>
        <li v-for="(msg, index) in historialWS" :key="index">{{ msg }}</li>
      </ul>
    </div>

    <q-separator class="q-my-lg" />

    <h3>HTTP (GET)</h3>
    <q-btn label="Llamar a HTTP" color="primary" @click="llamarHTTP" />
    <div class="q-mt-sm"><strong>Respuesta HTTP:</strong> {{ mensajeHTTP }}</div>

    <q-separator class="q-my-lg" />

    <q-btn label="Ir a Info.vue" to="/info" color="accent" />

  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { io } from 'socket.io-client'

const socket = io('http://localhost:3001')

const var1 = ref(null)
const var2 = ref(null)
const var3 = ref(null)
const varVal = ref([null, null, null])

const mensajeHTTP = ref('')
const mensajeWS = ref('')
const historialWS = ref([])

// HTTP
async function llamarHTTP() {
  const res = await fetch('http://localhost:3001/api/mensaje')
  const data = await res.json()
  mensajeHTTP.value = data.mensaje
}

// WebSocket: enviar mensaje desde input
function enviarPorWebSocket() {
  socket.emit('mensaje', mensajeWS.value)
}

onMounted(() => {
  socket.on('respuesta', (data) => {
    historialWS.value.push(data)
  })

  socket.on('update1', (data) => {
    var1.value = data
  })

  socket.on('update2', (data) => {
    var2.value = data
  })

  socket.on('update3', (data) => {
    var3.value = data
  })

  socket.on('Values', (data) => {
    varVal.value[0] = data[0]
    varVal.value[1] = data[1]
    varVal.value[2] = data[2]
  })
})
</script>
